import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Home from "./pages/Home";
import "tailwindcss/tailwind.css";
import Navbar from "./components/Navbar";
import SearchBox from "./components/SearchBar";
import Slider from "./components/Slider";

const App: React.FC = () => {
  return (
    <>
      <Navbar />
      <SearchBox />
      <br />
      <br />

      <Slider />
      <Home />
    </>
  );
};

export default App;
