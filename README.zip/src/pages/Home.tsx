import React from "react";

const Home: React.FC = () => {
  return <div className="container mx-auto mt-4">HOME PAGE</div>;
};

export default Home;
