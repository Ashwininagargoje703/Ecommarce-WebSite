import React from "react";

const ProdunctDetailsPage: React.FC = () => {
  return <div className="container mx-auto mt-4">ProdunctDetailsPage</div>;
};

export default ProdunctDetailsPage;
