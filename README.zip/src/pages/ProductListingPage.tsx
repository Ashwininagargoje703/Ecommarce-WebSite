import React from "react";

const ProdunctListingPage: React.FC = () => {
  return <div className="container mx-auto mt-4">ProdunctListingPage</div>;
};

export default ProdunctListingPage;
