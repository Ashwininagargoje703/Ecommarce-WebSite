import React from "react";

const SearchPage: React.FC = () => {
  return <div className="container mx-auto mt-4">SearchPage</div>;
};

export default SearchPage;
